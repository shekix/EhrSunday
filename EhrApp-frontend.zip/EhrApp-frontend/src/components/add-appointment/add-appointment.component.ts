import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AppointmentService } from '../../services/appointment.service';
import { formatDate } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-appointment',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './add-appointment.component.html',
  styleUrl: './add-appointment.component.css'
})
export class AddAppointmentComponent {

  Specializations:any[] = [];
  Providers:any[] = [];
  date = formatDate(new Date(),'yyyy-MM-dd','en');
  aptDetails:any;

  constructor(private appointmentApi:AppointmentService,private route:Router){}

  addAppointmentForm = new FormGroup({
    patientId:new FormControl('',[Validators.required]),
    providerId:new FormControl('',[Validators.required]),
    appointmentDate:new FormControl('',[Validators.required]),
    appointmentTime:new FormControl('',[Validators.required]),
    cheifComplaint:new FormControl('',[Validators.required]),
    status:new FormControl('Scheduled',[Validators.required]),
    fee:new FormControl({value:'',disabled:true})
    })


    getSpecializations(){
      this.appointmentApi.getSpecialization().subscribe((data:any)=>{
        this.Specializations = data;
        })
    }

    getProviders(){
      this.appointmentApi.getProviders().subscribe((data:any)=>{
        this.Providers = data;    
      })
    }

    getProvidersById(event:any){
      this.Providers = [];
      this.appointmentApi.getProviderById(event.target.value).subscribe((data:any)=>{
        this.Providers = data;
        console.log(this.Providers);
      })
    }

    changefee(event:any){
      var provider =  this.Providers.filter(x=>x.id == event.target.value)
      this.addAppointmentForm.get('fee')?.setValue(provider[0].visitingCharge) 
    }

    async book(){
      this.aptDetails = {
        patientId:sessionStorage.getItem('id'),
        providerId:this.addAppointmentForm.get('providerId')?.value,
        appointmentDate:formatDate(this.addAppointmentForm.get('appointmentDate')?.value!,'yyyy-MM-dd','en'),
        appointmentTime:this.addAppointmentForm.get('appointmentTime')?.value,
        cheifComplaint:this.addAppointmentForm.get('cheifComplaint')?.value,
        fee:this.addAppointmentForm.get('fee')?.value
      }

     this.appointmentApi.setAptDetails(this.aptDetails);

      this.route.navigate(['home/payment']); 
    }


    get ProviderId() : FormControl{
      return this.addAppointmentForm.get('providerId') as FormControl;
    } 
    get aptDate() : FormControl{
      return this.addAppointmentForm.get('appointmentDate') as FormControl;
    }
    get aptTime() : FormControl{
      return this.addAppointmentForm.get('appointmentTime') as FormControl;
    }
    get complaint() : FormControl{
      return this.addAppointmentForm.get('cheifComplaint') as FormControl;
    }
}

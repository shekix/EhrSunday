import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { formatDate } from '@angular/common';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  userinfo:any; 
  imageSrc:any;
  pfp:any;
  userId = sessionStorage.getItem('id')
  userType = sessionStorage.getItem('role');
  Genders:any[] = [];
  BloodGroups:any[] = [];
  Countries:any[] = [];
  States:any[] = [];
  Qualifications:any[] = [];
  Specializations:any[] = [];
  selectedFile:File | null = null;

  constructor(private authApi:AuthService,private router:Router,private userService:UserService,private toast:ToastrService){}

  regsitrationForm = new FormGroup({
    id:new FormControl(this.userId),
    firstName: new FormControl('', [Validators.required,Validators.maxLength(15)]),
    lastName: new FormControl('',[Validators.required,Validators.maxLength(15)]),
    email: new FormControl("",[Validators.required,Validators.email]),
    dob : new FormControl('',[Validators.required]),
    genderId : new FormControl('',[Validators.required]),
    bloodGroupId : new FormControl('',[Validators.required]),
    mobile:new FormControl('',[Validators.required,Validators.pattern("^[0-9]{10}$")]),
    country: new FormControl("",[Validators.required]),
    stateId: new FormControl("",[Validators.required]),
    city : new FormControl('',[Validators.required]),
    pincode: new FormControl("",[Validators.required,Validators.pattern("^[0-9]{6}$")]),
    address: new FormControl("",[Validators.required]),
    qualificationId: new FormControl("",[Validators.required]),
    specializationId: new FormControl("",[Validators.required]),
    registrationNumber: new FormControl("",[Validators.required]),
    visitingCharge: new FormControl("",[Validators.required])
    })


    ngOnInit(){
      this.loadUser();
      if(this.userType=='Patient'){
        this.regsitrationForm.get('qualificationId')?.clearValidators();
        this.regsitrationForm.get('specializationId')?.clearValidators();
        this.regsitrationForm.get('registrationNumber')?.clearValidators();
        this.regsitrationForm.get('visitingCharge')?.clearValidators();
      
        this.regsitrationForm.get('qualificationId')?.updateValueAndValidity();
        this.regsitrationForm.get('specializationId')?.updateValueAndValidity();
        this.regsitrationForm.get('registrationNumber')?.updateValueAndValidity();
        this.regsitrationForm.get('visitingCharge')?.updateValueAndValidity();
      }
    }



    loadUser(){
      this.userService.getUser(this.userId).subscribe(async (data:any)=>{
        this.userinfo = data;
  
        this.pfp = "https://localhost:7055"+this.userinfo.profileImage;
        this.userService.updateProfilePic("https://localhost:7055"+this.userinfo.profileImage);

 

        this.regsitrationForm.patchValue({
          firstName: this.userinfo.firstName,
          lastName: this.userinfo.lastName,
          email: this.userinfo.email,
          dob: formatDate(this.userinfo.dob,"yyyy-MM-dd","en"),
          genderId:this.userinfo.genderId,
          bloodGroupId:this.userinfo.bloodGroupId,
          mobile: this.userinfo.mobile,
          country: this.userinfo.country,
          stateId: this.userinfo.stateId,
          city:this.userinfo.city,
          pincode: this.userinfo.pincode,
          address: this.userinfo.address,
          qualificationId:this.userinfo.qualificationId,
          specializationId:this.userinfo.specializationId,
          registrationNumber:this.userinfo.registrationNumber,
          visitingCharge:this.userinfo.visitingCharge
        });    
        await this.getCountries();
        await this.getStatesById(this.userinfo.country);
        await this.getGenders();
        await this.getBloodGroups();
        await this.getQualifications();
        await this.getSpecializations();
      })
    }


    async getCountries(){
      this.authApi.getCountries().subscribe((data:any)=>{
        this.Countries = data;
        })
    }

    async getStates(event : any){
      this.authApi.getStates(event.target.value).subscribe((data:any) =>{
        this.States = data; 
        })
      }

      async getStatesById(id: any){
        this.authApi.getStates(id).subscribe((data:any) =>{
          this.States = data; 
          })
        }

      async getGenders(){
      this.authApi.getGender().subscribe((data:any)=>{
        this.Genders = data;
        })
    }
    async getBloodGroups(){
      this.authApi.getBloodGroup().subscribe((data:any)=>{
        this.BloodGroups = data;
        })
    }  
    async getQualifications(){
      this.authApi.getQualification().subscribe((data:any)=>{
        this.Qualifications = data;
        })
    }

    async getSpecializations(){
      this.authApi.getSpecialization().subscribe((data:any)=>{
        this.Specializations = data;
        })
    }

    onFileChanged(event: any) {
      const file = event.target.files[0];
      if (file) {
        this.selectedFile = file;
        const reader = new FileReader();
        reader.onload = () => {
          this.imageSrc = reader.result;
        };
        reader.readAsDataURL(file);
      }
    }


    onSubmit(){   
      if (this.regsitrationForm.valid ) {
      const formData = new FormData();
      Object.keys(this.regsitrationForm.value).forEach((key) => {
        formData.append(key, this.regsitrationForm.get(key)?.value || '');
      });
      formData.append('profileImage', this.selectedFile!);

      this.userService.updateUser(formData).subscribe({
        next : (response:any)=>{
          this.loadUser();
          this.toast.success('Profile updated');
            this.router.navigateByUrl('home')
        } 
      }); 
    }
  }


  routeHome(){
    this.router.navigateByUrl('home')
  }

    get FirstName() : FormControl{
      return this.regsitrationForm.get('firstName') as FormControl;
    } 
    get LastName() : FormControl{
      return this.regsitrationForm.get('lastName') as FormControl;
    } 
    get Email() : FormControl{
      return this.regsitrationForm.get('email') as FormControl;
    } 
    get GenderId() : FormControl{
      return this.regsitrationForm.get('genderId') as FormControl;
    } 

    get BloodGroupId() : FormControl{
      return this.regsitrationForm.get('bloodGroupId') as FormControl;
    } 

    get Dob() : FormControl{
      return this.regsitrationForm.get('dob') as FormControl;
    } 

    get Mobile() : FormControl{
      return this.regsitrationForm.get('mobile') as FormControl;
    }
    get Country() : FormControl{
      return this.regsitrationForm.get('country') as FormControl;
    }
    get State() : FormControl{
      return this.regsitrationForm.get('stateId') as FormControl;
    }

    get City() : FormControl{
      return this.regsitrationForm.get('city') as FormControl;
    } 

    get Pincode() : FormControl{
      return this.regsitrationForm.get('pincode') as FormControl;
    }

    get Address() : FormControl{
      return this.regsitrationForm.get('address') as FormControl;
    } 

    get QualificationId() : FormControl{
      return this.regsitrationForm.get('qualificationId') as FormControl;
    } 

    get SpecializationId() : FormControl{
      return this.regsitrationForm.get('specializationId') as FormControl;
    } 

    get RegistrationNumber() : FormControl{
      return this.regsitrationForm.get('registrationNumber') as FormControl;
    } 

    get VisitingCharge() : FormControl{
      return this.regsitrationForm.get('visitingCharge') as FormControl;
    } 
}

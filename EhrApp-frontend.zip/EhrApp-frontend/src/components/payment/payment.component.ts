import { Component } from '@angular/core';
import { loadStripe } from '@stripe/stripe-js';
import { AppointmentService } from '../../services/appointment.service';
@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [],
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent {
  stripe: any;
  Elements: any;
  card: any;
  aptData:any;
constructor(private appointmentApi:AppointmentService){}

  ngOnInit(): void {

      this.appointmentApi.aptDetails$.subscribe( {
        next:(data:any) => {
          console.log(data);
        }
      })

    
    
    // loadStripe('pk_test_51QUPDm2K94hGf7CbFdRXftVkSb5gMF9s5BfQVK4HWCiZ5WLI1PydgMsYnMvl47RITYprOBmYGQyl35mqseEZErk300IO2eOyqL').then((stripe:any) => {
    //   this.stripe = stripe;
    //   this.Elements = stripe.elements();
    //   this.card = this.Elements.create('card');
    //   this.card.mount('#card-element');  // Add the card element to the DOM

    // });
  }


  // async handlePayment() {
  //   const amount = Number(sessionStorage.getItem('amount'));
    
  //   const paymentIntent = await this.appointmentApi.createPaymentIntent(amount).toPromise();

  //   const { clientSecret } = paymentIntent;

  //   // Confirm the payment
  //   const result = await this.stripe.confirmCardPayment(clientSecret, {
  //     payment_method: {
  //       card: this.card,
  //       billing_details: {
  //         name: 'Test User' // You can replace with dynamic user data
  //       }
  //     }
  //   });

  //   if (result.error) {
  //     console.log('Payment failed', result.error);
  //   } else {
  //     if (result.paymentIntent.status === 'succeeded') {
  //       alert('Payment successful!');
  //     }
  //   }

  // }
}

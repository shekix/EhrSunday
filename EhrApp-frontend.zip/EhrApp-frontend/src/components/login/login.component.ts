import { Component } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { AuthService } from '../../services/auth.service';
import { Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import * as bootstrap from 'bootstrap';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule,RouterLink,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  otpError : string = "";
  emailError:string = "";
  jwtHelperService = new JwtHelperService();



  constructor(private authApi:AuthService,private router:Router,private toast:ToastrService){

  }

  loginForm = new FormGroup({
    username : new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required]),
  })

  otpForm = new FormGroup({
    otp:new FormControl('', [Validators.required])
  })

  forgotPasswordForm = new FormGroup({
    email:new FormControl('',[Validators.required,Validators.email])
  })


  onLogin(){
    var data = {... this.loginForm.value}
    if(this.loginForm.valid){
      this.authApi.loginUser(data).subscribe({
        next: (response: any) => {
          this.toast.info('check your mail for otp');
          const otpModal = new bootstrap.Modal(document.getElementById('otpModal')!);
          otpModal.show();
          sessionStorage.setItem("username",data.username!=null?data.username:"");
        },
        error: (error) => {
          if (error.status === 401) {
            this.toast.error('Invalid username or password.')
          } else {
            this.toast.error('An unexpected error occurred. Please try again later.')
            console.log(error);
            
          }
        },
      });
    }
    else{
      this.loginForm.markAllAsTouched();
    }
  }

  verifyOtp(){
    var data = {
      username:sessionStorage.getItem('username'),
      otp:this.otpForm.value.otp
    }
    this.authApi.verifyOtp(data).subscribe({
      next: (response: any) => {
        this.toast.success('you have successfully logged in')
        const otpModal = bootstrap.Modal.getInstance(document.getElementById('otpModal')!);
        otpModal?.hide();
        sessionStorage.setItem("token",response);
        this.loadCurrentUser();
        this.router.navigateByUrl('home');
     
        this.router.navigateByUrl('home/appointments')

      },
      error: (error) => {
        if (error.status === 400) {
          this.otpError = 'Invalid OTP. Please try again.'
        } else {
          alert('An unexpected error occurred. Please try again later.')
        }
      },
    })
  }


  loadCurrentUser(){
    const token = sessionStorage.getItem("token");
    const userInfo = token != null? this.jwtHelperService.decodeToken(token) : null;
    const data = userInfo ? {
      username:userInfo["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"],
      role:userInfo["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"],
      userid:userInfo["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"]
    }:null;
    sessionStorage.setItem("name",data?.username)
    sessionStorage.setItem("role",data?.role);
    sessionStorage.setItem("id",data?.userid);
  }

  openForgotPasswordModal() {
    const modalElement = document.getElementById('forgotPasswordModal');
    if (modalElement) {
      const forgotPasswordModal = new bootstrap.Modal(modalElement);
      forgotPasswordModal.show();
    }
  }


  submitForgotPassword()
  {
    const data = this.forgotPasswordForm.value.email
    
    this.authApi.forgotPass(data).subscribe({
      next: (response: any) => {
        const forgotPasswordModal = bootstrap.Modal.getInstance(document.getElementById('forgotPasswordModal')!);
        forgotPasswordModal?.hide();
        this.toast.success('Login details sent to your mail');
      },
      error: (error) => {
        this.emailError = 'Invalid Email. Please try again.'
      },
    })
  }


  Register(){
    var role = sessionStorage.getItem('role')
    if(role == 'Provider'){
      this.router.navigate(['/providerRegister'])
    }else{
      this.router.navigate(['/patientRegister'])
    }
    
  }

  get Username() : FormControl{
    return this.loginForm.get('username') as FormControl;
  } 
  get Password() : FormControl{
    return this.loginForm.get('password') as FormControl;
  } 

  get Otp():FormControl {
    return this.otpForm.get('otp') as FormControl
  }
}

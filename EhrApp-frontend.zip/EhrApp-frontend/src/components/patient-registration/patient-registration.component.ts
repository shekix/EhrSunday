import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router, RouterLink } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-patient-registration',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule,RouterLink],
  templateUrl: './patient-registration.component.html',
  styleUrl: './patient-registration.component.css'
})
export class PatientRegistrationComponent {
  Genders:any[] = [];
  BloodGroups:any[] = [];
  Countries:any[] = [];
  States:any[] = [];
  selectedFile:File | null = null;

  constructor(private authApi:AuthService,private router:Router){}

  regsitrationForm = new FormGroup({
    firstName: new FormControl('', [Validators.required,Validators.maxLength(15)]),
    lastName: new FormControl('',[Validators.required,Validators.maxLength(15)]),
    email: new FormControl("",[Validators.required,Validators.email]),
    dob : new FormControl('',[Validators.required]),
    genderId : new FormControl('',[Validators.required]),
    bloodGroupId : new FormControl('',[Validators.required]),
    mobile:new FormControl('',[Validators.required,Validators.pattern("^[0-9]{10}$")]),
    userType: new FormControl(2),
    country: new FormControl("",[Validators.required]),
    stateId: new FormControl("",[Validators.required]),
    city : new FormControl('',[Validators.required]),
    pincode: new FormControl("",[Validators.required,Validators.pattern("^[0-9]{6}$")]),
    address: new FormControl("",[Validators.required])
    })



    getCountries(){
      this.authApi.getCountries().subscribe((data:any)=>{
        this.Countries = data;
        })
    }

    getStates(event : any){
      this.authApi.getStates(event.target.value).subscribe((data:any) =>{
        this.States = data; 
        })
      }

    getGenders(){
      this.authApi.getGender().subscribe((data:any)=>{
        this.Genders = data;
        })
    }
    getBloodGroups(){
      this.authApi.getBloodGroup().subscribe((data:any)=>{
        this.BloodGroups = data;
        })
    }  

    onFileChanged(event: any) {
      const file = event.target.files[0];
      if (file) {
        this.selectedFile = file;
      }
    }



    onSubmit(){
      console.log(this.regsitrationForm.value);
      
      if (this.regsitrationForm.valid ) {
      const formData = new FormData();
      Object.keys(this.regsitrationForm.value).forEach((key) => {
        formData.append(key, this.regsitrationForm.get(key)?.value || '');
      });
      formData.append('profileImage', this.selectedFile!);

      this.authApi.registerUser(formData).subscribe({
        next : (response:any)=>{
        Swal.fire({
          position: "top-end",
          icon: "success",
          title: "Check your Email for login details",
          showConfirmButton: false,
          timer: 2500
        });
        this.router.navigate(['/login'])
      },
      error : (error)=>{
        if(error.status === 409){
          Swal.fire({
            position: "top-end",
            icon: "error",
            title: "user with this email already exists",
            showConfirmButton: false,
            timer: 2500
          });
        }
      }
    })
    }
    else{
    this.regsitrationForm.markAllAsTouched();
    }
  }



    get FirstName() : FormControl{
      return this.regsitrationForm.get('firstName') as FormControl;
    } 
    get LastName() : FormControl{
      return this.regsitrationForm.get('lastName') as FormControl;
    } 
    get Email() : FormControl{
      return this.regsitrationForm.get('email') as FormControl;
    } 
    get GenderId() : FormControl{
      return this.regsitrationForm.get('genderId') as FormControl;
    } 

    get BloodGroupId() : FormControl{
      return this.regsitrationForm.get('bloodGroupId') as FormControl;
    } 

    get Dob() : FormControl{
      return this.regsitrationForm.get('dob') as FormControl;
    } 

    get Mobile() : FormControl{
      return this.regsitrationForm.get('mobile') as FormControl;
    }
    get Country() : FormControl{
      return this.regsitrationForm.get('country') as FormControl;
    }
    get State() : FormControl{
      return this.regsitrationForm.get('stateId') as FormControl;
    }

    get City() : FormControl{
      return this.regsitrationForm.get('city') as FormControl;
    } 

    get Pincode() : FormControl{
      return this.regsitrationForm.get('pincode') as FormControl;
    }

    get Address() : FormControl{
      return this.regsitrationForm.get('address') as FormControl;
    } 

    get UserType() : FormControl{
      return this.regsitrationForm.get('userType') as FormControl;
    } 

}

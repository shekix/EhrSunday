import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

   http = inject(HttpClient)
   private url = 'https://localhost:7055/api/Appointment';

     public addAppointment(data:any):Observable<any>{
       return this.http.post<any>(`${this.url}/addAppointment`,data );
     }

     public getSpecialization():Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/Specializations`);
     }

     public getProviders():Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/Providers`);
     }

     public getProviderById(id:any):Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/ProvidersById?Id=${id}`);
     }

     public createPaymentIntent(amount: number): Observable<any> {
      return this.http.post(`${this.url}/create-payment-intent`, { amount });
    }

    aptDetailsSubject:BehaviorSubject<any> = new BehaviorSubject(null);
    aptDetails$ = this.aptDetailsSubject.asObservable();

     setAptDetails(details: any) {
      this.aptDetailsSubject.next(details);
      console.log(details);
    }
}

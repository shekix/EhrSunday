﻿using Domain.User;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Appointment
{
    public class Appointment
    {
        public int Id { get; set; }

        [ForeignKey("User")]
        public int PatientId { get; set; }
        public Domain.User.User User { get; set; }
        public int ProviderId {  get; set; }
        public DateOnly AppointmentDate {  get; set; }
        public TimeOnly AppointmentTime { get; set; }
        public required string CheifComplaint {  get; set; }
        public required string Status { get; set; }
        public required string Fee {  get; set; }
    }
}

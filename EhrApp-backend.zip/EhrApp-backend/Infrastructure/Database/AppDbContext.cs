﻿using Domain.Appointment;
using Domain.Provider;
using Domain.StateCity;
using Domain.User;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Database
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<BloodGroup> BloodGroups { get; set; }
        public DbSet<Gender> Genders { get; set; }
        public DbSet<userType> UserType { get; set; }
        public DbSet<Country> Countries { get; set; }
        public DbSet<State> States { get; set; }
        public DbSet<Specialization> Specializations { get; set; }
        public DbSet<Qualification> Qualifications { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<OneTimePasswords> OneTimePasswords { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
    }
}

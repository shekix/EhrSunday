﻿using Core.Interfaces;
using Infrastructure.Database;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Models.User;
using Domain.User;
using Microsoft.AspNetCore.Http;
using Org.BouncyCastle.Crypto.Generators;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Services
{
    public class RegistrationLoginService : IRegistrationLoginService
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _config;
        private readonly IEmailService _emailService;
        private readonly IJwtService _jwtService;
       

        public RegistrationLoginService(AppDbContext context, IConfiguration config, IEmailService emailService, IJwtService jwtService)
        {
            _context = context;
            _config = config;
            _emailService = emailService;
            _jwtService = jwtService;
           
        }

        public async Task<userRegistrationDto> userRegistration(userRegistrationDto dto)
        {
            var existingUser = _context.Users.Where(u => u.Email == dto.Email).FirstOrDefault();
            if (existingUser != null)
            {
                return null;
            }
            var uniqueUserName = "";
            if(dto.UserType == 1)
            {
                uniqueUserName = $"PR_{dto.LastName.ToUpper()}{dto.FirstName.ToUpper().Substring(0, 1)}{dto.Dob.ToString("ddMMyy")}";
            }
            else
            {
                uniqueUserName = $"PT_{dto.LastName.ToUpper()}{dto.FirstName.ToUpper().Substring(0, 1)}{dto.Dob.ToString("ddMMyy")}";
            }

            var uniquePassword = GeneratePassword();

            string profileImagePath = ImagePath(dto.ProfileImage!);

            var user = new User
            {
                UserType = dto.UserType,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                Dob = dto.Dob,
                GenderId = dto.GenderId,
                BloodGroupId = dto.BloodGroupId,
                Mobile = dto.Mobile,
                Country = dto.Country,
                StateId  = dto.StateId,
                City = dto.City,
                Address = dto.Address,
                Pincode = dto.Pincode,
                ProfileImage = profileImagePath,
                UserName = uniqueUserName,
                Password = HashPassword(uniquePassword),
                QualificationId = dto.QualificationId,
                SpecializationId = dto.SpecializationId,
                RegistrationNumber = dto.RegistrationNumber,
                VisitingCharge = dto.VisitingCharge,
            };

            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            await _emailService.SendEmailAsync(dto.Email, $"Welcome! {dto.FirstName}",
             $"use the below credentials to log into your account\n" +
             $"\nUserName:\t{uniqueUserName}\nPassword:\t{uniquePassword}");
            return await Task.FromResult(dto);

        }



        public async Task<bool> userLogin(userLoginDto dto)
        {
            var exitingUser = _context.Users.Where(u => u.UserName == dto.Username).FirstOrDefault();
            if (exitingUser == null)
            {
                return false;
            }
            if (VerifyPassword(dto.Password, exitingUser.Password))
            {
                var otp = GenerateOtp();
                var otpRegistration = _context.OneTimePasswords.Where(u => u.userId == exitingUser.Id).FirstOrDefault();
                if (otpRegistration != null)
                {
                    otpRegistration.LastestOtp = otp;
                    await _context.SaveChangesAsync();
                    await _emailService.SendEmailAsync(exitingUser.Email, $"Hello! {exitingUser.FirstName}",
                    $"Your one time password is \n" +
                    $"{otp}");
                    return true;
                }
                var newOtpRegistration = new OneTimePasswords
                {
                    userId = exitingUser.Id,
                    LastestOtp = otp
                };

                await _context.OneTimePasswords.AddAsync(newOtpRegistration);
                await _context.SaveChangesAsync();
                await _emailService.SendEmailAsync(exitingUser.Email, $"Hello! {exitingUser.FirstName}",
                $"Your one time password is \n" +
                $"{otp}");
                return true;
            }
            return false;
        }



        public async Task<string> userVerification(OtpVerficationDto dto)
        {
            var exitingUser = await _context.Users.Where(u => u.UserName == dto.Username).FirstOrDefaultAsync();

            var user = await _context.OneTimePasswords.Where(u => u.userId == exitingUser.Id).FirstOrDefaultAsync();

            var role = exitingUser.UserType == 1 ? "Provider" : "Patient";

            if (user.LastestOtp == dto.Otp)
            {
                return await Task.FromResult(_jwtService.GenerateToken(exitingUser.UserName, exitingUser.Id, new List<string> { role }));
            }
            return "unsuccessful";
        }


        public async Task<string> forgotPassword(string email)
        {
            var existingUser = await _context.Users.Where(u => u.Email == email).FirstOrDefaultAsync();
            if (existingUser != null)
            {
                var newPassword = GeneratePassword();
                existingUser.Password = HashPassword(newPassword);

                await _context.SaveChangesAsync();
                await _emailService.SendEmailAsync(existingUser.Email, $"Hello! {existingUser.FirstName}\n",
                $"Your  username is {existingUser.UserName}\n" +
                $"\nYour password is {newPassword}");
                return "successful";
            }
            return "unsuccessful";
        }

        public async Task<string> changePassword(chanegPassDta dto)
        {
            var existingUser = await _context.Users.Where(u => u.Id == dto.Id).FirstOrDefaultAsync();
            if (existingUser != null)
            {
                existingUser.Password = HashPassword(dto.Password);
                await _context.SaveChangesAsync();
                return "successful";
            }
            return "unsuccessful";
        }


        public static string GeneratePassword(int length = 8)
        {
            const string validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder result = new StringBuilder();
            Random random = new Random();

            while (0 < length--)
            {
                result.Append(validChars[random.Next(validChars.Length)]);
            }

            return result.ToString();
        }

        public static string HashPassword(string plainTextPassword)
        {
            // Hash the password with a salt
            return BCrypt.Net.BCrypt.HashPassword(plainTextPassword);
        }

        public bool VerifyPassword(string plainTextPassword, string hashedPassword)
        {
            // Verify the password
            return BCrypt.Net.BCrypt.Verify(plainTextPassword, hashedPassword);
        }

        public static string GenerateOtp()
        {
            var rng = new Random();
            return rng.Next(100000, 999999).ToString();

        }

        public string ImagePath(IFormFile image)
        {
            if (image != null)
            {

                var folderPath = Path.Combine("wwwroot", "profile_images");

                // Ensure the directory exists
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Generate a unique file name
                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(image.FileName)}";
                var filePath = Path.Combine(folderPath, fileName);

                // Save the file asynchronously
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream); // Synchronous operation for this case
                }

                // Return relative path
                return $"/profile_images/{fileName}";


            }
            return $"/profile_images/default.jpg";
        }
    }
}

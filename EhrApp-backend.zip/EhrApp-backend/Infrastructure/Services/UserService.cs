﻿using Core.Interfaces;
using Domain.User;
using Infrastructure.Database;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class UserService
    {
        private readonly AppDbContext _context;

        public UserService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<User> getUserInfo(int id)
        {
            var existingUser = await _context.Users.Where(u => u.Id == id).FirstOrDefaultAsync();
            if (existingUser != null)
            {
                return existingUser;
            }
            return null;
        }

        public async Task<string> updateUserInfo(userUpdateDto dto)
        {
            var existingUser = await _context.Users.Where(u => u.Id == dto.Id).FirstOrDefaultAsync();
            string profileImagePath = "";
            if (dto.ProfileImage != null)
            {
                profileImagePath = await ImagePath(dto.ProfileImage);
            }
            if (existingUser != null)
            {
                if (profileImagePath != "")
                {
                    existingUser.ProfileImage = profileImagePath;
                }

                existingUser.FirstName = dto.FirstName;
                existingUser.LastName = dto.LastName;
                existingUser.Email = dto.Email;
                existingUser.Dob = dto.Dob;
                existingUser.GenderId = dto.GenderId;
                existingUser.BloodGroupId = dto.BloodGroupId;
                existingUser.Mobile = dto.Mobile;
                existingUser.Country = dto.Country;
                existingUser.StateId = dto.StateId;
                existingUser.City = dto.City;
                existingUser.Address = dto.Address;
                existingUser.Pincode = dto.Pincode;
                existingUser.QualificationId = dto.QualificationId;
                existingUser.SpecializationId = dto.SpecializationId;
                existingUser.RegistrationNumber = dto.RegistrationNumber;
                existingUser.VisitingCharge = dto.VisitingCharge;

                await _context.SaveChangesAsync();
                return "success";
            }
            return "unsuccessful";
        }




        public async Task<string> ImagePath(IFormFile image)
        {
            if (image != null || image.Length != 0)
            {

                var folderPath = Path.Combine("wwwroot", "profile_images");

                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(image.FileName)}";
                var filePath = Path.Combine(folderPath, fileName);


                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream);
                }

                return $"/profile_images/{fileName}";
            }
            return "";
        }
    }
}


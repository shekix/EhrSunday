﻿using Core.Interfaces;
using Core.Models.Appointment;
using Core.Models.User;
using Domain.Appointment;
using Domain.Provider;
using Domain.User;
using Infrastructure.Database;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class AppointmentService
    {
        private readonly AppDbContext _context;
        private readonly IEmailService _emailService;

        public AppointmentService(AppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        public async Task<ScheduleAppointmentDto> scheduleAppointment(ScheduleAppointmentDto dto)
        {
            var appointment = new Appointment
            {
                PatientId = dto.PatientId,
                ProviderId = dto.ProviderId,
                AppointmentDate = dto.AppointmentDate,
                AppointmentTime = dto.AppointmentTime,
                CheifComplaint = dto.CheifComplaint,
                Status = dto.Status,
                Fee = dto.Fee,
            };

            await _context.Appointments.AddAsync(appointment);
            return dto;
        }

        public async Task<IEnumerable<Specialization>> GetSpecializations()
        {
            var result = await _context.Specializations.ToListAsync();
            return result;
        }

        public async Task<IEnumerable<User>> GetProviders()
        {
            var result = await _context.Users.Where(u=>u.Id == 1).ToListAsync();
            return result;
        }

        public async Task<IEnumerable<User>> GetProvidersbySpeicalization(int id)
        {
            var result = await _context.Users.Where(u=>u.SpecializationId == id).ToListAsync();
            return result;
        }
    }
}
